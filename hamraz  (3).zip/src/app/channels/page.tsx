
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Upload, BookOpen, Smile, Languages, House, Award, Download, Share2, PackageOpen, Gamepad2, Feather, Heart, PawPrint, ThumbsUp, UserPlus, MessageSquare } from "lucide-react";
import { useUser } from "@/firebase";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";


const channels = [
    { 
        id: "stories", 
        title: "Kids Stories", 
        icon: BookOpen,
        description: "Share captivating stories for children.",
        videos: [
            { title: "The Little Bear's Adventure", author: "Aria G.", url: "https://videos.pexels.com/video-files/854341/854341-hd_1280_720_25fps.mp4" },
            { title: "The Magical Treehouse", author: "Kian N.", url: "https://videos.pexels.com/video-files/853874/853874-hd_1280_720_25fps.mp4" },
        ]
    },
    { 
        id: "humor", 
        title: "Funny Antics", 
        icon: Smile,
        description: "Post your funny clips, sweet moments, and stand-up bits.",
         videos: [
            { title: "My Cat is a Comedian", author: "Sara K.", url: "https://videos.pexels.com/video-files/5494391/5494391-hd_1280_720_25fps.mp4" },
        ]
    },
    { 
        id: "poetry", 
        title: "Poetry Corner", 
        icon: Feather,
        description: "Share beautiful poetry readings from kids and adults.",
         videos: [
            { title: "Twinkle, Twinkle, Little Star", author: "Jane Taylor", performer: "Kian, age 5", url: "https://videos.pexels.com/video-files/3691359/3691359-hd_1280_720_25fps.mp4" },
        ]
    },
     { 
        id: "moments", 
        title: "Precious Moments", 
        icon: Heart,
        description: "Share messages of love, gratitude, and children's dreams.",
         videos: [
            { title: "A message of love", author: "Layla", url: "https://videos.pexels.com/video-files/5494391/5494391-hd_1280_720_25fps.mp4"},
            { title: "A beautiful sunset", author: "Sara", url: "https://videos.pexels.com/video-files/854341/854341-hd_1280_720_25fps.mp4"},
        ]
    },
      { 
        id: "pets", 
        title: "Pets & Kids", 
        icon: PawPrint,
        description: "Share heartwarming videos of the special bond between children and animals.",
         videos: [
            { title: "A Purrfect Friendship", author: "Kian's Dad", url: "https://videos.pexels.com/video-files/7188143/7188143-hd_1280_720_25fps.mp4" },
        ]
    },
    { 
        id: "language", 
        title: "Language Learning", 
        icon: Languages,
        description: "Share tips and lessons for learning new languages.",
         videos: [
            { title: "5 English Phrases You Need", author: "Parsa F.", url: "https://videos.pexels.com/video-files/2882112/2882112-hd_1280_720_30fps.mp4" },
        ]
    },
    { 
        id: "homemaking", 
        title: "Home & Family", 
        icon: House,
        description: "For women to share tips on family and home matters.",
         videos: [
            { title: "Quick & Healthy Recipes", author: "Bahar Z.", url: "https://videos.pexels.com/video-files/3209828/3209828-hd_1280_720_30fps.mp4" },
        ]
    },
    {
        id: "unboxing",
        title: "Unboxing & Reviews",
        icon: PackageOpen,
        description: "For YouTubers to unbox and review products for family, kids, and home.",
        videos: [
            { title: "Newest Smart Toy Review", author: "TechFamily", url: "https://videos.pexels.com/video-files/3846237/3846237-hd_1280_720_25fps.mp4" },
        ]
    },
    {
        id: "gaming",
        title: "Game Reviews",
        icon: Gamepad2,
        description: "For gamers to review and promote games for all age ranges.",
        videos: [
            { title: "Fun Mobile Game for Kids", author: "GamerDad", url: "https://videos.pexels.com/video-files/7162121/7162121-hd_1280_720_25fps.mp4" },
        ]
    }
];

type Video = { title: string; author: string; url: string };

const VideoGallery = ({ videos }: { videos: Video[] }) => {
    const { toast } = useToast();

    const handleShare = async (video: Video) => {
        if (navigator.share) {
            try {
                await navigator.share({
                    title: video.title,
                    text: `Check out this video on Hamraz: "${video.title}" by ${video.author}`,
                    url: window.location.href,
                });
                toast({ title: "Shared successfully!" });
            } catch (error) {
                console.error('Error sharing:', error);
                toast({ variant: "destructive", title: "Could not share", description: "An error occurred while trying to share the video." });
            }
        } else {
            toast({ variant: "destructive", title: "Not Supported", description: "Your browser does not support the Web Share API." });
        }
    };
    
    const handleDownload = (video: Video) => {
        try {
            const a = document.createElement('a');
            a.href = video.url;
            a.download = `${video.title.replace(/\s+/g, '_')}.mp4`;
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            toast({ title: "Download started!" });
        } catch (error) {
            console.error('Error downloading:', error);
            toast({ variant: "destructive", title: "Download failed", description: "Could not start the video download." });
        }
    }


    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video, index) => (
                <Card key={index} className="shadow-lg hover:shadow-primary/20 transition-all duration-300 transform hover:-translate-y-1 flex flex-col">
                    <div className="aspect-video bg-muted rounded-t-lg overflow-hidden">
                        <video src={video.url} className="w-full h-full object-cover" controls />
                    </div>
                    <CardHeader>
                        <CardTitle className="text-lg">{video.title}</CardTitle>
                        <CardDescription>by {video.author}</CardDescription>
                    </CardHeader>
                     <CardContent className="mt-auto flex flex-wrap gap-2">
                        <Button variant="outline" size="sm" onClick={() => toast({ title: "Liked!" })}>
                            <ThumbsUp className="mr-2 h-4 w-4" /> Like
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => toast({ title: `Followed ${video.author}!` })}>
                            <UserPlus className="mr-2 h-4 w-4" /> Follow
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => toast({ title: "Comment feature coming soon!" })}>
                            <MessageSquare className="mr-2 h-4 w-4" /> Comment
                        </Button>
                    </CardContent>
                    <CardFooter className="grid grid-cols-2 gap-2">
                        <Button variant="outline" onClick={() => handleDownload(video)}>
                            <Download className="mr-2 h-4 w-4" /> Download
                        </Button>
                         <Button onClick={() => handleShare(video)}>
                            <Share2 className="mr-2 h-4 w-4" /> Share
                        </Button>
                    </CardFooter>
                </Card>
            ))}
        </div>
    );
};


const UploadVideoForm = () => {
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [channel, setChannel] = useState("");
    const [videoFile, setVideoFile] = useState<File | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const { toast } = useToast();
    const { user } = useUser();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim() || !channel || !description.trim() || !videoFile) {
            toast({
                variant: "destructive",
                title: "Incomplete Form",
                description: "Please fill out all fields and upload a video.",
            });
            return;
        }
        setIsLoading(true);
        await new Promise(resolve => setTimeout(resolve, 2000));
        console.log("Video Upload:", { userId: user?.uid, title, description, channel, fileName: videoFile.name });
        setIsLoading(false);
        setIsSubmitted(true);
    };
    
    if (isSubmitted) {
        return (
            <Card className="w-full shadow-lg text-center animate-in fade-in-50 mt-6">
                <CardHeader>
                    <CardTitle className="text-2xl font-headline mt-4">Video Submitted!</CardTitle>
                    <CardDescription>Thank you for your contribution! Your video is now under review and will be published shortly.</CardDescription>
                </CardHeader>
                <CardFooter>
                    <Button className="w-full" onClick={() => setIsSubmitted(false)}>Upload Another Video</Button>
                </CardFooter>
            </Card>
        );
    }
    
    return (
        <Card className="w-full shadow-lg mt-8">
            <form onSubmit={handleSubmit}>
                <CardHeader>
                    <CardTitle className="text-2xl font-headline">Share Your Content</CardTitle>
                    <CardDescription>Upload a 2-minute video to one of our channels.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                         <div className="space-y-2">
                            <Label htmlFor="video-title">Video Title</Label>
                            <Input id="video-title" placeholder="e.g., The Best Chocolate Chip Cookie Recipe" value={title} onChange={(e) => setTitle(e.target.value)} disabled={isLoading || !user} required />
                        </div>
                        <div className="space-y-2">
                             <Label htmlFor="channel-select">Channel</Label>
                            <Select onValueChange={setChannel} value={channel} disabled={isLoading || !user}>
                                <SelectTrigger id="channel-select">
                                    <SelectValue placeholder="Select a channel" />
                                </SelectTrigger>
                                <SelectContent>
                                    {channels.map(ch => (
                                        <SelectItem key={ch.id} value={ch.id}>{ch.title}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="video-description">Description</Label>
                        <Textarea id="video-description" placeholder="Briefly describe what your video is about." value={description} onChange={(e) => setDescription(e.target.value)} disabled={isLoading || !user} required />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="video-upload">Upload Your 2-Minute Video</Label>
                        <Input
                            id="video-upload"
                            type="file"
                            accept="video/*"
                            onChange={(e) => e.target.files && setVideoFile(e.target.files[0])}
                            disabled={isLoading || !user}
                            required
                            className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                        />
                         {videoFile && <p className="text-xs text-muted-foreground pt-1">Selected: {videoFile.name}</p>}
                    </div>

                    {!user && <p className="text-sm text-center text-destructive font-medium">Please sign in to upload a video.</p>}
                </CardContent>
                <CardFooter>
                    <Button type="submit" className="w-full" disabled={isLoading || !user}>
                        {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Submitting...</> : <><Upload className="mr-2 h-4 w-4" />Publish Video</>}
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
};


export default function ChannelsPage() {
    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold font-headline mb-2">Channels</h1>
                <p className="text-muted-foreground">Watch, create, and share videos with the community.</p>
            </div>
             <Alert variant="default" className="bg-primary/10 border-primary/30">
                <Award className="h-4 w-4 text-primary" />
                <AlertTitle className="text-primary">Get Featured!</AlertTitle>
                <AlertDescription>
                    Selected videos will be published on Hamraz's official social media channels. The condition for publication is your membership in the Hamraz channel on that platform.
                </AlertDescription>
            </Alert>


            <Tabs defaultValue={channels[0].id} className="w-full">
                <TabsList className="grid w-full grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-9">
                    {channels.map(channel => (
                        <TabsTrigger key={channel.id} value={channel.id} className="gap-2 text-xs md:text-sm">
                            <channel.icon className="h-4 w-4 shrink-0"/> <span>{channel.title}</span>
                        </TabsTrigger>
                    ))}
                </TabsList>
                {channels.map(channel => (
                    <TabsContent key={channel.id} value={channel.id} className="mt-6">
                        <Alert className="mb-6">
                            <channel.icon className="h-4 w-4" />
                            <AlertTitle>{channel.title}</AlertTitle>
                            <AlertDescription>{channel.description}</AlertDescription>
                        </Alert>
                        <VideoGallery videos={channel.videos} />
                    </TabsContent>
                ))}
            </Tabs>
            
            <UploadVideoForm />
        </div>
    );
}
